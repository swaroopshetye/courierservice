﻿SET IDENTITY_INSERT [dbo].[Role] ON
INSERT INTO [dbo].[Role] ([role_id], [role_name]) VALUES (1, N'ADMIN')
INSERT INTO [dbo].[Role] ([role_id], [role_name]) VALUES (2, N'DISPATCHER')
INSERT INTO [dbo].[Role] ([role_id], [role_name]) VALUES (3, N'DELIVERY_PERSONNEL')
INSERT INTO [dbo].[Role] ([role_id], [role_name]) VALUES (4, N'CUSTOMER')
SET IDENTITY_INSERT [dbo].[Role] OFF
